import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from tqdm import tqdm
import warnings

plt.style.use("fivethirtyeight")
warnings.filterwarnings("ignore")

movies_md = pd.read_csv("C:/Users/sanja/Downloads/movies_metadata.csv/movies_metadata.csv")
movies_keywords = pd.read_csv("C:/Users/sanja/Downloads/keywords.csv/keywords.csv")
movies_credits = pd.read_csv("C:/Users/sanja/Downloads/credits.csv/credits.csv")


movies_md = movies_md[movies_md['vote_count'] >= 55]


movies_md = movies_md[['id', 'original_title', 'overview', 'genres']]

movies_md['title'] = movies_md['original_title']

movies_md.reset_index(inplace=True, drop=True)

movies_credits = movies_credits[['id', 'cast']]

movies_md['id'] = movies_md['id'].astype(int)

movies_df = pd.merge(movies_md, movies_keywords, on='id', how='left')

movies_df.head()

movies_df.reset_index(inplace=True, drop=True)

movies_df = pd.merge(movies_df, movies_credits, on='id', how='left')
movies_df.reset_index(inplace=True, drop=True)

movies_df.head()

movies_df['genre'] = movies_df['genres'].apply(lambda x: [i['name'] for i in eval(x)])

movies_df['genre'] = movies_df['genre'].apply(lambda x: [i.replace(" ", "") for i in x])

movies_df.head()

movies_df['keywords'].fillna('[]', inplace=True)

movies_df['genre'] = movies_df['genre'].apply(lambda x: ' '.join(x))

movies_df.drop('genres', axis=1, inplace=True)

movies_df.head()

movies_df['cast'] = movies_df['cast'].apply(lambda x: [i['name'] for i in eval(x)])
movies_df['cast'] = movies_df['cast'].apply(lambda x: ' '.join([i.replace(" ", "") for i in x]))

movies_df['keywords'] = movies_df['keywords'].apply(lambda x: [i['name'] for i in eval(x)])
movies_df['keywords'] = movies_df['keywords'].apply(lambda x: ' '.join([i.replace(" ", "") for i in x]))

movies_df['tags'] = movies_df['overview']+' '+movies_df['keywords']+' '+movies_df['cast']+' '+movies_df['genre']+' '+movies_df['original_title']

movies_df.drop(['genre', 'original_title', 'keywords', 'cast', 'overview'], axis=1, inplace=True)

movies_df.drop(movies_df[movies_df['tags'].isnull()].index, inplace=True)

movies_df.drop_duplicates(inplace=True)

from sklearn.feature_extraction.text import TfidfVectorizer

tfidf = TfidfVectorizer(max_features=5000)

vectorized_data = tfidf.fit_transform(movies_df['tags'].values)

vectorized_dataframe = pd.DataFrame(vectorized_data.toarray(), index=movies_df['tags'].index.tolist())

vectorized_dataframe.head()

from sklearn.decomposition import TruncatedSVD

svd = TruncatedSVD(n_components=3000)

reduced_data = svd.fit_transform(vectorized_dataframe)

reduced_data

svd.explained_variance_ratio_.cumsum()

from sklearn.metrics.pairwise import cosine_similarity

similarity = cosine_similarity(reduced_data)

def recomendation_system(movie):
    id_of_movie = movies_df[movies_df['title']==movie].index[0]
    distances = similarity[id_of_movie]
    movie_list = sorted(list(enumerate(distances)), reverse=True, key=lambda x:x[1])[1:15]
    for movie_id in movie_list:
        print(movies_df.iloc[movie_id[0]].title)


recomendation_system('The Matrix')


