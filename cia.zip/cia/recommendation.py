import pandas as pd
import numpy as np
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.metrics.pairwise import cosine_similarity


class pred:
    metadata_path = pd.read_csv("C:/Users/sanja/Downloads/movies_metadata.csv/movies_metadata.csv")
    keywords_path = pd.read_csv("C:/Users/sanja/Downloads/keywords.csv/keywords.csv")
    credits_path = pd.read_csv("C:/Users/sanja/Downloads/credits.csv/credits.csv")
 
    def __init__(self, metadata_path, keywords_path, credits_path):
        self.movies_md = pd.read_csv(metadata_path)
        self.movies_keywords = pd.read_csv(keywords_path)
        self.movies_credits = pd.read_csv(credits_path)
        self.movies_df = None
        self.similarity = None
        self.tfidf = None
        self.svd = None
        
    def clean_data(self):
        self.movies_md = self.movies_md[self.movies_md['vote_count'] >= 55]
        self.movies_md = self.movies_md[['id', 'original_title', 'overview', 'genres']]
        self.movies_md['title'] = self.movies_md['original_title']
        self.movies_md.reset_index(inplace=True, drop=True)
        self.movies_credits = self.movies_credits[['id', 'cast']]
        self.movies_md['id'] = self.movies_md['id'].astype(int)
        self.movies_df = pd.merge(self.movies_md, self.movies_keywords, on='id', how='left')
        self.movies_df.reset_index(inplace=True, drop=True)
        self.movies_df = pd.merge(self.movies_df, self.movies_credits, on='id', how='left')
        self.movies_df.reset_index(inplace=True, drop=True)
        self.movies_df['genre'] = self.movies_df['genres'].apply(lambda x: [i['name'] for i in eval(x)])
        self.movies_df['genre'] = self.movies_df['genre'].apply(lambda x: [i.replace(" ", "") for i in x])
        self.movies_df['keywords'].fillna('[]', inplace=True)
        self.movies_df['genre'] = self.movies_df['genre'].apply(lambda x: ' '.join(x))
        self.movies_df.drop('genres', axis=1, inplace=True)
        self.movies_df['cast'] = self.movies_df['cast'].apply(lambda x: [i['name'] for i in eval(x)])
        self.movies_df['cast'] = self.movies_df['cast'].apply(lambda x: ' '.join([i.replace(" ", "") for i in x]))
        self.movies_df['keywords'] = self.movies_df['keywords'].apply(lambda x: [i['name'] for i in eval(x)])
        self.movies_df['keywords'] = self.movies_df['keywords'].apply(lambda x: ' '.join([i.replace(" ", "") for i in x]))
        self.movies_df['tags'] = self.movies_df['overview']+' '+self.movies_df['keywords']+' '+self.movies_df['cast']+' '+self.movies_df['genre']+' '+self.movies_df['original_title']
        self.movies_df.drop(['genre', 'original_title', 'keywords', 'cast', 'overview'], axis=1, inplace=True)
        self.movies_df.drop(self.movies_df[self.movies_df['tags'].isnull()].index, inplace=True)
        self.movies_df.drop_duplicates(inplace=True)

    def fit(self):
        self.tfidf = TfidfVectorizer(max_features=5000)
        vectorized_data = self.tfidf.fit_transform(self.movies_df['tags'].values)
        vectorized_dataframe = pd.DataFrame(vectorized_data.toarray(), index=self.movies_df['tags'].index.tolist())
        self.svd = TruncatedSVD(n_components=3000)
        reduced_data = self.svd.fit_transform(vectorized_dataframe)
        self.similarity = cosine_similarity(reduced_data)

    def recommend(self, movie):
        if self.movies_df is None or self.similarity is None:
            print("Please call the 'fit' method first to generate the recommendation system.")
            return None

        idx = self.movies_df[self.movies_df['title'].str.lower() == movie.lower()].index

        if len(idx) == 0:
           print("Movie not found.")
           return None
        else:
           idx = idx[0]
           sim_scores = list(enumerate(self.similarity[idx]))
           sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
           sim_scores = sim_scores[1:11]
           movie_indices = [i[0] for i in sim_scores]
           return self.movies_df['title'].iloc[movie_indices]       
l=pred()
with open('model.pkl', 'wb') as f:
    pickle.dump(l, f)